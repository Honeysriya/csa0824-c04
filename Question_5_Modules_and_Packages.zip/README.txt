Question 5 - Modules and Packages
Contains the four organisation approaches and import demonstration. The attendance package includes reader.py, stats.py and report.py as package modules.
Run the relevant main_*.py or task5_imports.py file.
