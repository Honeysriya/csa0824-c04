"""attendance package: reader, stats and report sub-modules."""
from .reader import read_records
from .stats import percentage, compute, three_day_absentees
from .report import write_report, write_absentee_report
