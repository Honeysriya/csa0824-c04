from pathlib import Path

def read_records(folder):
    for path in sorted(Path(folder).glob("*.txt")):
        with open(path, encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split(",")
                if len(parts) == 3 and parts[2] in ("P", "A"):
                    yield tuple(parts)
