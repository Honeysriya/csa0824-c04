def write_report(pcts):
    for reg, pct in sorted(pcts.items()):
        print(f"{reg} {pct:6.2f}%")

def write_absentee_report(regs):                        # NEW
    print("Absent 3 days in a row:", ", ".join(regs) or "none")
