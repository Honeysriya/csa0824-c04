import sys, time

print("'attendance.stats' loaded before import?", "attendance.stats" in sys.modules)
t = time.perf_counter()
import attendance.stats                                   # style 1
t1 = time.perf_counter() - t
print("style 1  import attendance.stats           ->", attendance.stats.percentage(3, 4))

from attendance import stats                              # style 2
print("style 2  from attendance import stats      ->", stats.percentage(3, 4))

from attendance.stats import percentage                   # style 3
print("style 3  from attendance.stats import percentage ->", percentage(3, 4))

t = time.perf_counter()
import attendance.stats                                   # second import = cache lookup
t2 = time.perf_counter() - t
print("'attendance.stats' in sys.modules now?", "attendance.stats" in sys.modules)
print(f"first import {t1*1000:.3f} ms, second import {t2*1000:.4f} ms")
