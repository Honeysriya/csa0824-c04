from attendance.reader import read_records
from attendance.stats import compute, three_day_absentees
from attendance.report import write_report, write_absentee_report

records = list(read_records("../data"))
write_report(compute(records))
write_absentee_report(three_day_absentees(records))                 # NEW line
