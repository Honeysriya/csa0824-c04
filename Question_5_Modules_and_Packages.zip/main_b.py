import attendance_lib as lib

records = list(lib.read_records("../data"))
lib.write_report(lib.compute(records))
lib.write_absentee_report(lib.three_day_absentees(records))       # NEW line
