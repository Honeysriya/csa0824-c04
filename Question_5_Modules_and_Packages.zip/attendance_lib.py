from pathlib import Path

def read_records(folder):
    for path in sorted(Path(folder).glob("*.txt")):
        with open(path, encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split(",")
                if len(parts) == 3 and parts[2] in ("P", "A"):
                    yield tuple(parts)

def percentage(present, total):
    return 100 * present / total

def compute(records):
    present, total = {}, {}
    for reg, date, status in records:
        total[reg] = total.get(reg, 0) + 1
        present[reg] = present.get(reg, 0) + (status == "P")
    return {r: percentage(present[r], total[r]) for r in total}

def three_day_absentees(records):                       # NEW
    streak, result = {}, set()
    for reg, date, status in sorted(records, key=lambda r: r[1]):
        streak[reg] = streak.get(reg, 0) + 1 if status == "A" else 0
        if streak[reg] >= 3:
            result.add(reg)
    return sorted(result)

def write_report(pcts):
    for reg, pct in sorted(pcts.items()):
        print(f"{reg} {pct:6.2f}%")

def write_absentee_report(regs):                        # NEW
    print("Absent 3 days in a row:", ", ".join(regs) or "none")
