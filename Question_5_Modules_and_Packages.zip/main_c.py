import reader
import stats
import report

records = list(reader.read_records("../data"))
report.write_report(stats.compute(records))
report.write_absentee_report(stats.three_day_absentees(records))    # NEW line
