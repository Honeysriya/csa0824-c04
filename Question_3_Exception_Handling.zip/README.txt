Question 3 - Exception Handling
Contains the exception demonstrations, custom exception processor, complete try statement and misuse experiment.
Run the required task3_*.py file for each sub-question.
