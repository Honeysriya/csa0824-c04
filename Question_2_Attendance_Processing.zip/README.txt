Question 2 - Attendance Processing
Files: task2_attendance.py (main solution), task2_alt.py (comparison), attendance_oct/ (sample daily attendance files).
Run: python task2_attendance.py
