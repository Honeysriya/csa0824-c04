import os
from festreg.main import run

accepted, events, errors = run("fest_input", "fest_output")
print("Files in fest_output:", sorted(os.listdir("fest_output")))
for name in ("master_list.csv", "summary.txt", "errors.log"):
    print(f"\n--- {name} ---")
    print(open(os.path.join("fest_output", name), encoding="utf-8").read(), end="")
print("\n--- events/Quiz.txt ---")
print(open("fest_output/events/Quiz.txt", encoding="utf-8").read(), end="")
