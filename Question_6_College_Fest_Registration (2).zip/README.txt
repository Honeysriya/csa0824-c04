Question 6 - College Fest Registration
Contains the festreg package, sample department input files and alternative performance comparison.
Run: python run_fest.py (from this folder).
