import os
from .errors import RegistrationError, DuplicateRegistration
from .validator import parse_registration

def read_department_file(path, seen, accepted, error_log):
    """Read one department file. Never raises: every problem goes to error_log."""
    name = os.path.basename(path)
    try:
        with open(path, encoding="utf-8") as f:
            for line_no, line in enumerate(f, start=1):
                if line.strip() == "":
                    continue
                try:
                    record = parse_registration(line)
                    if record["reg"] in seen:                     # set -> O(1) average
                        raise DuplicateRegistration(f"register number {record['reg']} already registered")
                except RegistrationError as err:
                    error_log.append(f"{name} line {line_no}: {type(err).__name__}: {err}")
                else:
                    seen.add(record["reg"])
                    accepted.append(record)
    except FileNotFoundError:
        error_log.append(f"{name}: department file is missing")
    except PermissionError:
        error_log.append(f"{name}: permission denied")
    except UnicodeDecodeError:
        error_log.append(f"{name}: file is not valid UTF-8")
