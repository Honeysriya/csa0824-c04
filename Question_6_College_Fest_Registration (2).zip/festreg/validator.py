from .errors import DamagedLine, InvalidEmail

def valid_email(email):
    """Validate with string methods only."""
    if email == "" or " " in email or email.count("@") != 1:
        return False
    local, domain = email.split("@")
    if local == "" or "." not in domain:
        return False
    if domain.startswith(".") or domain.endswith(".") or ".." in domain:
        return False
    return len(domain.rsplit(".", 1)[1]) >= 2

def parse_registration(line):
    """'reg,name,dept,email,ev1;ev2' -> dict. Raises DamagedLine / InvalidEmail."""
    parts = [p.strip() for p in line.strip().split(",")]
    if len(parts) != 5:
        raise DamagedLine(f"expected 5 fields, found {len(parts)}")
    reg, name, dept, email, events = parts
    if not (reg.isdigit() and name and dept and events):
        raise DamagedLine("register number must be digits and no field may be empty")
    if not valid_email(email):
        raise InvalidEmail(f"invalid e-mail {email!r}")
    return {"reg": reg, "name": name.title(), "dept": dept.upper(),
            "email": email.lower(), "events": [e.strip().title() for e in events.split(";") if e.strip()]}
