class RegistrationError(Exception):
    """Base class for every problem found in one registration line."""

class DamagedLine(RegistrationError):
    """Wrong number of fields or an empty required field."""

class InvalidEmail(RegistrationError):
    """The e-mail address does not follow the basic format."""

class DuplicateRegistration(RegistrationError):
    """The register number has already been accepted."""
