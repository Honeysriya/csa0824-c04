import os
from .reader import read_department_file
from .writer import write_master, write_event_files, write_summary, write_error_log

DEPARTMENTS = ["CSE", "ECE", "MECH", "IT", "AI"]

def run(input_dir, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    seen, accepted, error_log = set(), [], []
    for dept in DEPARTMENTS:
        read_department_file(os.path.join(input_dir, dept + ".txt"), seen, accepted, error_log)
    write_master(accepted, output_dir)
    events = write_event_files(accepted, output_dir)
    write_summary(accepted, events, error_log, output_dir)
    write_error_log(error_log, output_dir)
    return accepted, events, error_log
