import os

def write_master(records, folder):
    with open(os.path.join(folder, "master_list.csv"), "w", encoding="utf-8") as f:
        f.write("reg,name,dept,email,events\n")
        for r in sorted(records, key=lambda r: r["reg"]):
            f.write(f"{r['reg']},{r['name']},{r['dept']},{r['email']},{';'.join(r['events'])}\n")

def write_event_files(records, folder):
    events = {}
    for r in records:
        for ev in r["events"]:
            events.setdefault(ev, []).append(r)
    os.makedirs(os.path.join(folder, "events"), exist_ok=True)
    for ev, people in events.items():
        with open(os.path.join(folder, "events", ev.replace(" ", "_") + ".txt"), "w", encoding="utf-8") as f:
            for r in sorted(people, key=lambda r: r["reg"]):
                f.write(f"{r['reg']} {r['name']} ({r['dept']})\n")
    return events

def write_summary(records, events, error_log, folder):
    with open(os.path.join(folder, "summary.txt"), "w", encoding="utf-8") as f:
        f.write(f"Accepted registrations : {len(records)}\n")
        f.write(f"Problems logged        : {len(error_log)}\n")
        for ev in sorted(events):
            f.write(f"  {ev:<10}: {len(events[ev])} participants\n")

def write_error_log(error_log, folder):
    with open(os.path.join(folder, "errors.log"), "w", encoding="utf-8") as f:
        for line in error_log:
            f.write(line + "\n")
