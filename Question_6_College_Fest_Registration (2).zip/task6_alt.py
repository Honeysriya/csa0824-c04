import time

def with_list(regs):
    seen = []
    for r in regs:
        if r in seen:                 # linear search  -> O(n) each, O(n^2) total
            continue
        seen.append(r)
    return len(seen)

def with_set(regs):
    seen = set()
    for r in regs:
        if r in seen:                 # hash lookup -> O(1) average, O(n) total
            continue
        seen.add(r)
    return len(seen)

print(f"{'n':>7}{'list (s)':>12}{'set (s)':>12}")
for n in (2000, 4000, 8000, 16000):
    regs = [f"1925{i:05d}" for i in range(n)]
    row = [n]
    for fn in (with_list, with_set):
        t = time.perf_counter(); fn(regs); row.append(time.perf_counter() - t)
    print(f"{row[0]:>7}{row[1]:>12.4f}{row[2]:>12.5f}")
