Question 1 - File Processing
Files: task1_fixed.py (repaired solution), task1_alt.py (memory/time comparison), mess_oct.txt (sample input).
Run: python task1_fixed.py or python task1_alt.py
