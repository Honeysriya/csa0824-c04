Question 4 - File and Exception Forensics
Contains the faulty program, repaired program and file-handle experiment.
Run: python task4_fixed.py (repair) or the other task4_*.py files for demonstrations.
